import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AnimatePresence } from "framer-motion";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Registrations from "@/pages/registrations";
import Quiz from "@/pages/quiz";
import QuizDetail from "@/pages/quiz-detail";
import Posters from "@/pages/posters";
import Itinerary from "@/pages/itinerary";
import Contact from "@/pages/contact";
import Layout from "@/components/layout";

const queryClient = new QueryClient();

function Router() {
  return (
    <AnimatePresence mode="wait">
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/registrations" component={Registrations} />
        <Route path="/quiz" component={Quiz} />
        <Route path="/quiz/:slug" component={QuizDetail} />
        <Route path="/itinerary" component={Itinerary} />
        <Route path="/posters" component={Posters} />
        <Route path="/contact" component={Contact} />
        <Route component={NotFound} />
      </Switch>
    </AnimatePresence>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Layout>
            <Router />
          </Layout>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
