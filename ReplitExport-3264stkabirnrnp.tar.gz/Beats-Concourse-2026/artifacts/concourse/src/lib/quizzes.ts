export type QuizSlug = "accumbens" | "callosum" | "asterixis";

export type RoundDetail = {
  name: string;
  duration: string;
  description: string;
  emphasized?: boolean;
};

export type QuizConfig = {
  slug: QuizSlug;
  name: string;
  subtitle: string;
  intro: string;
  introNote?: string;
  formUrl: string;
  overview: {
    online: string;
    offline: string;
  };
  schedule: {
    online: {
      monthLabel: string;
      dayLabel: string;
      title: string;
      bullets: Array<{ icon: "calendar" | "clock" | "users" | "trophy"; text: string }>;
    };
    offline: {
      monthLabel: string;
      dayLabel: string;
      title: string;
      venue: string;
      quizDate: string;
      finalsOnly?: boolean;
      rounds?: RoundDetail[];
      finalsOnlyNote?: string;
    };
  };
  prizes: Array<{ position: string; amount: string }>;
};

const COMMON_VENUE = "Asmita Bhavan, Civil Hospital, Asarwa, Ahmedabad";

const FULL_ROUND_FORMAT: RoundDetail[] = [
  { name: "Written Round", duration: "30 min", description: "Top 18 teams advance to Pre-Finals." },
  { name: "Pre-Final Round", duration: "2.5 hrs", description: "Conducted thrice in groups of six teams; top 2 from each group advance — 6 teams in all." },
  { name: "Final Round", duration: "3.5 hrs", description: "The grand finale — six teams compete for the title." },
];

const FORM_URL_DEFAULT = "https://tally.so/r/81JL2k";
const FORM_URL_ASTERIXIS = "https://tally.so/r/ob0rOV";

export const QUIZZES: Record<QuizSlug, QuizConfig> = {
  accumbens: {
    slug: "accumbens",
    name: "Accumbens",
    subtitle: "Preclinical Quiz",
    intro: "The preclinical quiz testing the foundations of medicine — anatomy, physiology, and biochemistry.",
    formUrl: FORM_URL_DEFAULT,
    overview: {
      online: "Screening round.",
      offline: "Written + Pre-Finals + Finals.",
    },
    schedule: {
      online: {
        monthLabel: "May",
        dayLabel: "10",
        title: "Screening Round",
        bullets: [
          { icon: "calendar", text: "10th May 2026" },
          { icon: "clock", text: "45 minutes duration." },
          { icon: "users", text: "Single device per team with audio and video on." },
          { icon: "trophy", text: "Top 25 teams qualify for the offline round." },
        ],
      },
      offline: {
        monthLabel: "May",
        dayLabel: "22",
        title: "Offline Rounds",
        venue: COMMON_VENUE,
        quizDate: "22nd May",
        rounds: FULL_ROUND_FORMAT,
      },
    },
    prizes: [
      { position: "1st", amount: "₹7,500" },
      { position: "2nd", amount: "₹2,500" },
    ],
  },
  callosum: {
    slug: "callosum",
    name: "Callosum",
    subtitle: "Paraclinical Quiz",
    intro: "The paraclinical quiz exploring pathology, pharmacology, and microbiology.",
    formUrl: FORM_URL_DEFAULT,
    overview: {
      online: "Screening round.",
      offline: "Written + Pre-Finals + Finals.",
    },
    schedule: {
      online: {
        monthLabel: "May",
        dayLabel: "10",
        title: "Screening Round",
        bullets: [
          { icon: "calendar", text: "10th May 2026" },
          { icon: "clock", text: "45 minutes duration." },
          { icon: "users", text: "Single device per team with audio and video on." },
          { icon: "trophy", text: "Top 25 teams qualify for the offline round." },
        ],
      },
      offline: {
        monthLabel: "May",
        dayLabel: "23",
        title: "Offline Rounds",
        venue: COMMON_VENUE,
        quizDate: "23rd May",
        rounds: FULL_ROUND_FORMAT,
      },
    },
    prizes: [
      { position: "1st", amount: "₹10,000" },
      { position: "2nd", amount: "₹5,000" },
    ],
  },
  asterixis: {
    slug: "asterixis",
    name: "Asterixis",
    subtitle: "Clinical Quiz",
    intro: "The clinical quiz spanning all clinical subjects.",
    introNote: "Note :- Eligible for all students upto batch year 2020 (all UG plus recently passed out students)",
    formUrl: FORM_URL_ASTERIXIS,
    overview: {
      online: "Screening round.",
      offline: "Grand finale.",
    },
    schedule: {
      online: {
        monthLabel: "May",
        dayLabel: "18",
        title: "Screening Round",
        bullets: [
          { icon: "calendar", text: "18th May 2026" },
          { icon: "users", text: "Single device per team with audio and video on." },
        ],
      },
      offline: {
        monthLabel: "May",
        dayLabel: "24",
        title: "Grand Finale",
        venue: COMMON_VENUE,
        quizDate: "24th May",
      },
    },
    prizes: [
      { position: "1st", amount: "₹7,000" },
      { position: "2nd", amount: "₹5,000" },
      { position: "3rd", amount: "₹3,000" },
    ],
  },
};

export const QUIZ_ORDER: QuizSlug[] = ["accumbens", "callosum", "asterixis"];
