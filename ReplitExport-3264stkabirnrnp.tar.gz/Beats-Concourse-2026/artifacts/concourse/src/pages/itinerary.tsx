import { PageTransition, SectionReveal, usePageTitle } from "@/components/animations";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Clock } from "lucide-react";

type ScheduleEntry = { time: string; event: string };
type DaySchedule = { label: string; entries: ScheduleEntry[]; comingSoon?: boolean };

const DAYS: DaySchedule[] = [
  {
    label: "Day 1",
    entries: [
      { time: "9:00 am – 1:00 pm", event: "Workshops" },
      { time: "1:00 – 2:00 pm", event: "Lunch" },
      { time: "2:00 – 3:00 pm", event: "First Lecture" },
      { time: "3:00 – 4:00 pm", event: "Second Lecture" },
      { time: "4:00 – 5:00 pm", event: "Panel Discussion" },
      { time: "5:00 pm onwards", event: "Preclinical Quiz Offline Round" },
    ],
  },
  {
    label: "Day 2",
    entries: [
      { time: "9:30 am – 12:30 pm", event: "Workshops" },
      { time: "1:00 – 2:00 pm", event: "Lunch" },
      { time: "2:00 – 3:00 pm", event: "First Lecture" },
      { time: "3:00 – 4:00 pm", event: "Second Lecture" },
      { time: "4:00 – 5:00 pm", event: "Panel Discussion" },
      { time: "5:00 pm onwards", event: "Paraclinical Quiz Offline Round" },
    ],
  },
  {
    label: "Day 3",
    comingSoon: true,
    entries: [
      { time: "", event: "Clinical Quiz Offline Round" },
    ],
  },
];

export default function Itinerary() {
  usePageTitle("Itinerary");

  return (
    <PageTransition>
      <div className="pt-28 pb-16 md:pt-36 md:pb-24">
        <div className="container px-4 md:px-6 max-w-3xl mx-auto">

          <SectionReveal>
            <div className="text-center mb-16">
              <p className="text-sm md:text-base uppercase tracking-[0.2em] font-semibold text-primary/70 mb-4">Conference Schedule</p>
              <h1 className="text-5xl md:text-7xl font-serif text-primary mb-6">Itinerary</h1>
              <p className="text-lg md:text-xl text-muted-foreground font-light leading-relaxed max-w-xl mx-auto">
                A three-day programme of workshops, lectures, panel discussions, and quiz competitions.
              </p>
            </div>
          </SectionReveal>

          <SectionReveal>
            <Accordion type="multiple" className="w-full flex flex-col gap-4">
              {DAYS.map((day, di) => (
                <AccordionItem
                  key={di}
                  value={`day-${di}`}
                  className="bg-card rounded-2xl px-6 border border-border/50 shadow-sm data-[state=open]:border-primary/20"
                >
                  <AccordionTrigger className="text-2xl md:text-3xl font-serif text-primary hover:no-underline py-6">
                    {day.label}
                  </AccordionTrigger>
                  <AccordionContent className="pb-6">
                    {day.comingSoon && (
                      <p className="text-muted-foreground italic mb-4 text-base">Details coming soon.</p>
                    )}
                    <div className="space-y-0 divide-y divide-border/50">
                      {day.entries.map((entry, ei) => (
                        <div key={ei} className="flex items-start gap-4 py-4 first:pt-0 last:pb-0">
                          <div className="flex items-center gap-2 min-w-0 shrink-0 w-44 md:w-52">
                            <Clock className="w-4 h-4 text-primary/50 shrink-0" />
                            <span className="text-sm md:text-base font-mono text-muted-foreground leading-snug">
                              {entry.time || "—"}
                            </span>
                          </div>
                          <span className="text-base md:text-lg text-foreground leading-snug pt-0.5">{entry.event}</span>
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </SectionReveal>

        </div>
      </div>
    </PageTransition>
  );
}
