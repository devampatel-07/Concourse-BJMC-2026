import { PageTransition, SectionReveal, usePageTitle } from "@/components/animations";
import { ArrowUpRight } from "lucide-react";

export default function Posters() {
  usePageTitle("Posters & Papers");

  return (
    <PageTransition>
      <div className="pt-28 pb-24 md:pt-36 md:pb-32">
        <div className="container px-4 md:px-6 max-w-4xl mx-auto flex flex-col gap-8">

          <SectionReveal>
            <div className="text-center mb-8">
              <h1 className="text-5xl md:text-7xl font-serif text-primary mb-6">Posters &amp; Papers</h1>
              <p className="text-xl md:text-2xl text-muted-foreground font-light leading-relaxed max-w-2xl mx-auto">
                Poster and paper presentation details for Concourse 2026.
              </p>
            </div>
          </SectionReveal>

          {/* Rules & Regulations CTA */}
          <SectionReveal>
            <a
              href="https://drive.google.com/drive/folders/1-woBeq2iGgYNth2-2Yw2M8fF7rz48ExI"
              target="_blank"
              rel="noreferrer"
              className="block outline-none"
            >
              <div className="group relative overflow-hidden rounded-2xl border border-primary/20 bg-card hover:bg-secondary/40 transition-all duration-300 shadow-sm hover:shadow-md">
                <div className="absolute inset-0 bg-primary/5 translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-in-out" />
                <div className="relative z-10 flex items-center justify-between gap-4 px-7 py-6">
                  <div>
                    <div className="text-xs uppercase tracking-widest font-semibold text-primary/70 mb-1">Guidelines</div>
                    <div className="text-2xl md:text-3xl font-serif text-primary leading-tight">Click here for rules and regulations</div>
                  </div>
                  <ArrowUpRight className="w-6 h-6 text-primary shrink-0 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </div>
              </div>
            </a>
          </SectionReveal>

          {/* Closed Notice */}
          <SectionReveal>
            <div className="w-full bg-primary text-primary-foreground rounded-3xl px-8 py-16 text-center shadow-lg">
              <p className="text-xs uppercase tracking-[0.25em] font-semibold text-primary-foreground/60 mb-5">Submission Status</p>
              <p className="text-4xl md:text-5xl font-serif font-bold leading-snug text-primary-foreground">
                Registrations closed<br className="hidden md:block" /> for paper presentation
              </p>
            </div>
          </SectionReveal>

        </div>
      </div>
    </PageTransition>
  );
}
