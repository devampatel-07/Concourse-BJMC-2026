import { PageTransition, SectionReveal, StaggerContainer, StaggerItem, usePageTitle } from "@/components/animations";
import { Card, CardContent } from "@/components/ui/card";
import { Mail, Instagram, Phone, MapPin, ArrowUpRight } from "lucide-react";

export default function Contact() {
  usePageTitle("Contact Us");

  return (
    <PageTransition>
      <div className="pt-24 pb-16 md:pt-32 md:pb-24 bg-background min-h-[90dvh] flex flex-col justify-center">
        <div className="container px-4 md:px-6 max-w-4xl mx-auto">
          
          <SectionReveal>
            <div className="text-center mb-16">
              <h1 className="text-5xl md:text-7xl font-serif text-primary mb-6">Contact Us</h1>
              <p className="text-xl md:text-2xl text-muted-foreground font-light leading-relaxed">
                Have questions about the conference? Reach out to our team.
              </p>
            </div>
          </SectionReveal>

          <StaggerContainer className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl mx-auto">
            <StaggerItem className="md:col-span-2">
              <a href="mailto:beatsconcourse@gmail.com" className="block outline-none">
                <Card className="border-none shadow-sm hover:shadow-md transition-all duration-300 bg-card group overflow-hidden relative">
                  <div className="absolute inset-0 bg-primary/5 translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-in-out" />
                  <CardContent className="p-8 flex items-center gap-6 relative z-10">
                    <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center shrink-0 group-hover:scale-110 group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300">
                      <Mail className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-sm uppercase tracking-wider font-bold text-muted-foreground mb-1">Email</p>
                      <p className="text-xl md:text-2xl font-serif text-foreground group-hover:text-primary transition-colors">beatsconcourse@gmail.com</p>
                    </div>
                  </CardContent>
                </Card>
              </a>
            </StaggerItem>

            <StaggerItem className="md:col-span-2">
              <a href="https://instagram.com/beatsconcourse" target="_blank" rel="noreferrer" className="block outline-none">
                <Card className="border-none shadow-sm hover:shadow-md transition-all duration-300 bg-card group overflow-hidden relative">
                  <div className="absolute inset-0 bg-primary/5 translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-in-out" />
                  <CardContent className="p-8 flex items-center gap-6 relative z-10">
                    <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center shrink-0 group-hover:scale-110 group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300">
                      <Instagram className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-sm uppercase tracking-wider font-bold text-muted-foreground mb-1">Instagram</p>
                      <p className="text-xl md:text-2xl font-serif text-foreground group-hover:text-primary transition-colors">@beatsconcourse</p>
                    </div>
                  </CardContent>
                </Card>
              </a>
            </StaggerItem>

            <StaggerItem>
              <a href="tel:+919879046463" className="block outline-none h-full">
                <Card className="border-none shadow-sm hover:shadow-md transition-all duration-300 bg-card group overflow-hidden relative h-full">
                  <div className="absolute inset-0 bg-primary/5 translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-in-out" />
                  <CardContent className="p-8 flex flex-col gap-4 relative z-10 h-full">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center shrink-0 group-hover:scale-110 group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300">
                      <Phone className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-lg font-serif text-foreground mb-1">Rushil Shah</p>
                      <p className="text-muted-foreground">+91 98790 46463</p>
                    </div>
                  </CardContent>
                </Card>
              </a>
            </StaggerItem>

            <StaggerItem>
              <a href="tel:+919925310614" className="block outline-none h-full">
                <Card className="border-none shadow-sm hover:shadow-md transition-all duration-300 bg-card group overflow-hidden relative h-full">
                  <div className="absolute inset-0 bg-primary/5 translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-in-out" />
                  <CardContent className="p-8 flex flex-col gap-4 relative z-10 h-full">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center shrink-0 group-hover:scale-110 group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300">
                      <Phone className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-lg font-serif text-foreground mb-1">Tanay Shah</p>
                      <p className="text-muted-foreground">+91 99253 10614</p>
                    </div>
                  </CardContent>
                </Card>
              </a>
            </StaggerItem>

            <StaggerItem>
              <a href="tel:+919824095558" className="block outline-none h-full">
                <Card className="border-none shadow-sm hover:shadow-md transition-all duration-300 bg-card group overflow-hidden relative h-full">
                  <div className="absolute inset-0 bg-primary/5 translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-in-out" />
                  <CardContent className="p-8 flex flex-col gap-4 relative z-10 h-full">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center shrink-0 group-hover:scale-110 group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300">
                      <Phone className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-lg font-serif text-foreground mb-1">Parth Desai</p>
                      <p className="text-muted-foreground">+91 98240 95558</p>
                    </div>
                  </CardContent>
                </Card>
              </a>
            </StaggerItem>

            <StaggerItem>
              <a href="tel:+917016611266" className="block outline-none h-full">
                <Card className="border-none shadow-sm hover:shadow-md transition-all duration-300 bg-card group overflow-hidden relative h-full">
                  <div className="absolute inset-0 bg-primary/5 translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-in-out" />
                  <CardContent className="p-8 flex flex-col gap-4 relative z-10 h-full">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center shrink-0 group-hover:scale-110 group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300">
                      <Phone className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-lg font-serif text-foreground mb-1">Devam Patel</p>
                      <p className="text-muted-foreground">+91 70166 11266</p>
                    </div>
                  </CardContent>
                </Card>
              </a>
            </StaggerItem>
          </StaggerContainer>

          {/* Venue Map */}
          <SectionReveal>
            <div className="mt-16 max-w-3xl mx-auto">
              <a
                href="https://maps.app.goo.gl/aDGjg7RiPuaSLirH9?g_st=aw"
                target="_blank"
                rel="noreferrer"
                className="block outline-none"
              >
                <Card className="border-none shadow-sm hover:shadow-md transition-all duration-300 bg-card group overflow-hidden relative">
                  <div className="absolute inset-0 bg-primary/5 translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-in-out" />
                  <CardContent className="p-8 flex items-start gap-6 relative z-10">
                    <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center shrink-0 group-hover:scale-110 group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300">
                      <MapPin className="w-6 h-6" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm uppercase tracking-wider font-bold text-muted-foreground mb-1">Venue</p>
                      <p className="text-xl md:text-2xl font-serif text-foreground group-hover:text-primary transition-colors leading-tight">
                        B.J. Medical College, Asarwa, Ahmedabad
                      </p>
                      <p className="text-muted-foreground mt-2 text-sm flex items-center gap-1">
                        Open in Google Maps
                        <ArrowUpRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </a>
            </div>
          </SectionReveal>

        </div>
      </div>
    </PageTransition>
  );
}
