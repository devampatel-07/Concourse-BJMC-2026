import { Link, useRoute } from "wouter";
import { PageTransition, SectionReveal, usePageTitle } from "@/components/animations";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { ArrowLeft, Calendar, Clock, MapPin, Trophy, Users } from "lucide-react";
import { QUIZZES, type QuizSlug, type RoundDetail } from "@/lib/quizzes";
import NotFound from "@/pages/not-found";

const ICONS = {
  calendar: Calendar,
  clock: Clock,
  users: Users,
  trophy: Trophy,
} as const;

function RoundCard({ round }: { round: RoundDetail }) {
  if (round.emphasized) {
    return (
      <div className="rounded-xl bg-primary text-primary-foreground p-4">
        <div className="flex items-center justify-between gap-3 mb-1">
          <h5 className="text-base md:text-lg font-serif">{round.name}</h5>
          <span className="text-xs font-mono uppercase tracking-wider bg-white/15 px-2 py-1 rounded-full">{round.duration}</span>
        </div>
        <p className="text-base md:text-lg leading-relaxed text-primary-foreground/90">{round.description}</p>
      </div>
    );
  }
  return (
    <div className="rounded-xl bg-background/70 border border-border/60 p-4">
      <div className="flex items-center justify-between gap-3 mb-1">
        <h5 className="text-base md:text-lg font-serif text-primary">{round.name}</h5>
        <span className="text-xs font-mono uppercase tracking-wider text-muted-foreground bg-muted/60 px-2 py-1 rounded-full">{round.duration}</span>
      </div>
      <p className="text-base md:text-lg text-foreground leading-relaxed">{round.description}</p>
    </div>
  );
}

export default function QuizDetail() {
  const [, params] = useRoute("/quiz/:slug");
  const slug = params?.slug as QuizSlug | undefined;
  const quiz = slug ? QUIZZES[slug] : undefined;

  usePageTitle(quiz?.name ?? "Quiz");

  if (!quiz) {
    return <NotFound />;
  }

  const { online, offline } = quiz.schedule;

  return (
    <PageTransition>
      <div className="pt-24 pb-16 md:pt-32 md:pb-24">
        <div className="container px-4 md:px-6 max-w-4xl mx-auto">

          <SectionReveal>
            <Link href="/quiz" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors mb-8 group">
              <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-0.5" />
              All quizzes
            </Link>
          </SectionReveal>

          <SectionReveal>
            <div className="text-center mb-16">
              <p className="text-sm md:text-base uppercase tracking-[0.2em] font-semibold text-primary/70 mb-4">{quiz.subtitle}</p>
              <h1 className="text-5xl md:text-7xl font-serif text-primary mb-6 leading-tight">{quiz.name}</h1>
              <p className="text-lg md:text-xl text-muted-foreground font-light leading-relaxed max-w-2xl mx-auto">
                {quiz.intro}
              </p>
              {quiz.introNote && (
                <p className="mt-6 text-base md:text-lg text-foreground/80 max-w-2xl mx-auto italic">
                  {quiz.introNote}
                </p>
              )}
            </div>
          </SectionReveal>

          <SectionReveal>
            <Accordion type="single" collapsible className="w-full mb-20 gap-4 flex flex-col">
              {/* Overview & Rules */}
              <AccordionItem value="overview" className="bg-card rounded-2xl px-6 border border-border/50 shadow-sm data-[state=open]:border-primary/20">
                <AccordionTrigger className="text-xl md:text-2xl font-serif text-primary hover:no-underline py-6">
                  Overview &amp; Rules
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground text-lg leading-relaxed pb-6">
                  <p><strong>Mode of quiz:</strong> Online + Offline.</p>
                  <p><strong>Online:</strong> {quiz.overview.online}</p>
                  <p><strong>Offline:</strong> {quiz.overview.offline}</p>
                  <p className="mt-4 text-destructive font-medium">Cross-college teams are not allowed.</p>
                </AccordionContent>
              </AccordionItem>

              {/* Schedule & Format */}
              <AccordionItem value="schedule" className="bg-card rounded-2xl px-6 border border-border/50 shadow-sm data-[state=open]:border-primary/20">
                <AccordionTrigger className="text-xl md:text-2xl font-serif text-primary hover:no-underline py-6">
                  Schedule &amp; Format
                </AccordionTrigger>
                <AccordionContent className="pb-6">
                  <div className="space-y-8">
                    {/* Stage 1 — Online */}
                    <div className="rounded-2xl bg-secondary/40 border border-primary/10 overflow-hidden">
                      <div className="flex items-center gap-4 px-5 py-5 border-b border-primary/10">
                        <div className="flex flex-col items-center justify-center w-16 h-16 rounded-xl bg-primary text-primary-foreground shrink-0 shadow-sm">
                          <span className="text-[10px] font-bold uppercase tracking-widest opacity-80">{online.monthLabel}</span>
                          <span className="text-2xl font-serif font-bold leading-none mt-0.5">{online.dayLabel}</span>
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="text-xs uppercase tracking-widest font-semibold text-primary/70 mb-1">Stage 1 · Online</div>
                          <div className="text-xl md:text-2xl font-serif text-primary leading-tight">{online.title}</div>
                        </div>
                      </div>
                      <div className="px-5 py-5 space-y-3 text-base md:text-lg text-foreground leading-relaxed">
                        {online.bullets.map((b, i) => {
                          const Icon = ICONS[b.icon];
                          return (
                            <div key={i} className="flex items-start gap-3">
                              <Icon className="w-5 h-5 text-primary/60 shrink-0 mt-1" />
                              <p>{b.text}</p>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Stage 2 — Offline */}
                    <div className="rounded-2xl bg-secondary/40 border border-primary/10 overflow-hidden">
                      <div className="flex items-center gap-4 px-5 py-5 border-b border-primary/10">
                        <div className="flex flex-col items-center justify-center w-16 h-16 rounded-xl bg-primary text-primary-foreground shrink-0 shadow-sm">
                          <span className="text-[10px] font-bold uppercase tracking-widest opacity-80">{offline.monthLabel}</span>
                          <span className="text-2xl font-serif font-bold leading-none mt-0.5">{offline.dayLabel}</span>
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="text-xs uppercase tracking-widest font-semibold text-primary/70 mb-1">Stage 2 · Offline</div>
                          <div className="text-xl md:text-2xl font-serif text-primary leading-tight">{offline.title}</div>
                        </div>
                      </div>

                      {/* Venue + date */}
                      <div className="px-5 pt-5 pb-2 space-y-3 text-base md:text-lg text-foreground leading-relaxed">
                        <div className="flex items-start gap-3">
                          <Calendar className="w-5 h-5 text-primary/60 shrink-0 mt-1" />
                          <p><span className="font-semibold">{offline.quizDate}</span></p>
                        </div>
                        <div className="flex items-start gap-3">
                          <MapPin className="w-5 h-5 text-primary/60 shrink-0 mt-1" />
                          <p>{offline.venue}</p>
                        </div>
                      </div>

                      {/* Round details */}
                      {offline.rounds && offline.rounds.length > 0 ? (
                        <div className="px-5 py-5 space-y-4">
                          <div className="text-xs uppercase tracking-widest font-semibold text-primary/70">Round format</div>
                          {offline.rounds.map((r, i) => <RoundCard key={i} round={r} />)}
                        </div>
                      ) : (
                        <div className="pb-5" />
                      )}
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Registration Fees */}
              <AccordionItem value="fees" className="bg-card rounded-2xl px-6 border border-border/50 shadow-sm data-[state=open]:border-primary/20">
                <AccordionTrigger className="text-xl md:text-2xl font-serif text-primary hover:no-underline py-6">
                  Registration Fees
                </AccordionTrigger>
                <AccordionContent className="pb-6">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-6">
                    <div className="bg-secondary/30 rounded-xl p-5 border border-primary/10">
                      <div className="text-sm font-bold uppercase tracking-wider text-primary mb-3">Early Bird (till 4th May)</div>
                      <div className="space-y-2 text-lg">
                        <div className="flex justify-between items-center">
                          <span className="flex items-center gap-2 text-muted-foreground"><Users className="w-4 h-4"/> Lone Wolf</span>
                          <span className="font-semibold text-foreground tabular-nums">₹100</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="flex items-center gap-2 text-muted-foreground"><Users className="w-5 h-5"/> Team of two</span>
                          <span className="font-semibold text-foreground tabular-nums">₹125</span>
                        </div>
                      </div>
                    </div>
                    <div className="bg-secondary/30 rounded-xl p-5 border border-primary/10">
                      <div className="text-sm font-bold uppercase tracking-wider text-primary mb-3">After 4th May</div>
                      <div className="space-y-2 text-lg">
                        <div className="flex justify-between items-center">
                          <span className="flex items-center gap-2 text-muted-foreground"><Users className="w-4 h-4"/> Lone Wolf</span>
                          <span className="font-semibold text-foreground tabular-nums">₹150</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="flex items-center gap-2 text-muted-foreground"><Users className="w-5 h-5"/> Team of two</span>
                          <span className="font-semibold text-foreground tabular-nums">₹200</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <p className="text-muted-foreground italic text-sm border-l-2 border-muted pl-3 py-1">
                    Note: If a delegate wishes to have lunch at the event on the day of the offline round, extra charges will apply.
                  </p>
                </AccordionContent>
              </AccordionItem>

              {/* Prizes */}
              <AccordionItem value="prizes" className="bg-card rounded-2xl px-6 border border-border/50 shadow-sm data-[state=open]:border-primary/20">
                <AccordionTrigger className="text-xl md:text-2xl font-serif text-primary hover:no-underline py-6">
                  Prizes
                </AccordionTrigger>
                <AccordionContent className="pb-6">
                  <div className={`grid gap-4 ${quiz.prizes.length === 3 ? "grid-cols-1 sm:grid-cols-3" : "grid-cols-2"}`}>
                    {quiz.prizes.map((p, i) => (
                      <div key={i} className="rounded-2xl bg-secondary/40 border border-primary/10 p-5 flex items-center gap-3">
                        <Trophy
                          className={`w-7 h-7 shrink-0 ${
                            i === 0 ? "text-yellow-500" : i === 1 ? "text-gray-400" : "text-amber-700"
                          }`}
                        />
                        <div>
                          <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{p.position}</div>
                          <div className="text-2xl md:text-3xl font-sans font-bold text-primary leading-tight tabular-nums tracking-tight">{p.amount}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </SectionReveal>

        </div>

        {/* Form Embed or Closed Notice */}
        {quiz.slug === "asterixis" ? (
          <SectionReveal>
            <div className="mt-16 md:mt-24 px-4 md:px-6">
              <div className="text-center mb-8 max-w-3xl mx-auto">
                <h2 className="text-3xl md:text-4xl font-serif text-primary mb-3">Register for {quiz.name}</h2>
                <p className="text-muted-foreground">Fill out the form below to secure your spot.</p>
              </div>
              <div className="w-full max-w-5xl mx-auto bg-card rounded-3xl overflow-hidden border border-border shadow-lg">
                <iframe
                  key={quiz.formUrl}
                  src={quiz.formUrl}
                  className="w-full border-0 block"
                  style={{ height: "min(1600px, 220vh)", minHeight: "1200px" }}
                  title={`${quiz.name} Registration Form`}
                  loading="lazy"
                >
                  Loading…
                </iframe>
              </div>
            </div>
          </SectionReveal>
        ) : (
          <SectionReveal>
            <div className="mt-16 md:mt-24 px-4 md:px-6 pb-24">
              <div className="w-full max-w-3xl mx-auto bg-primary text-primary-foreground rounded-3xl px-8 py-16 text-center shadow-lg">
                <p className="text-xs uppercase tracking-[0.25em] font-semibold text-primary-foreground/60 mb-4">Registration Status</p>
                <h2 className="text-4xl md:text-5xl font-serif font-bold mb-4">Registration closed</h2>
                <p className="text-lg md:text-xl text-primary-foreground/80 font-light">The quiz is tomorrow — good luck!</p>
              </div>
            </div>
          </SectionReveal>
        )}
      </div>
    </PageTransition>
  );
}
