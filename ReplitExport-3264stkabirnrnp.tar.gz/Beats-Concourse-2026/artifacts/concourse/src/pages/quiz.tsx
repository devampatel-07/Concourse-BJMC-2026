import { Link } from "wouter";
import { PageTransition, SectionReveal, StaggerContainer, StaggerItem, usePageTitle } from "@/components/animations";
import { Card } from "@/components/ui/card";
import { ArrowUpRight, BookOpen, FileText } from "lucide-react";
import { QUIZ_ORDER, QUIZZES } from "@/lib/quizzes";

export default function Quiz() {
  usePageTitle("Quiz");

  return (
    <PageTransition>
      <div className="pt-24 pb-16 md:pt-32 md:pb-24">
        <div className="container px-4 md:px-6 max-w-4xl mx-auto">

          <SectionReveal>
            <div className="text-center mb-16">
              <h1 className="text-5xl md:text-7xl font-serif text-primary mb-6">Quiz Competitions</h1>
              <p className="text-xl md:text-2xl text-muted-foreground font-light leading-relaxed max-w-2xl mx-auto">
                Test your knowledge across preclinical, paraclinical, and clinical subjects in our premier national-level academic quizzes.
              </p>
              <p className="mt-6 text-base md:text-lg text-foreground/80 max-w-2xl mx-auto italic">
                Note: Any UG student (irrespective of the year of study) may participate in any one or more of the quizzes.
              </p>
            </div>
          </SectionReveal>

          <StaggerContainer className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            {QUIZ_ORDER.map((slug) => {
              const q = QUIZZES[slug];
              return (
                <StaggerItem key={slug}>
                  <Link href={`/quiz/${slug}`} className="block h-full outline-none">
                    <Card className="bg-secondary/50 border-none text-center p-6 h-full flex flex-col items-center justify-center group transition-all duration-300 hover:bg-secondary hover:shadow-md hover:-translate-y-1 cursor-pointer relative overflow-hidden">
                      <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4 transition-all duration-300 group-hover:bg-primary group-hover:text-primary-foreground group-hover:scale-110">
                        <BookOpen className="w-6 h-6 text-primary group-hover:text-primary-foreground transition-colors" />
                      </div>
                      <h3 className="font-serif text-xl text-primary mb-1">{q.name}</h3>
                      <p className="text-muted-foreground text-sm uppercase tracking-wider font-medium">{q.subtitle}</p>
                      <div className="mt-4 flex items-center gap-1 text-xs font-mono uppercase tracking-widest text-primary/70 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-1 group-hover:translate-y-0">
                        View details
                        <ArrowUpRight className="w-3.5 h-3.5" />
                      </div>
                    </Card>
                  </Link>
                </StaggerItem>
              );
            })}
          </StaggerContainer>

          {/* Brochures CTA */}
          <SectionReveal>
            <a
              href="https://drive.google.com/drive/folders/1VVgeF4ZgULHp00YEEvMzY3t310dJ55n4"
              target="_blank"
              rel="noreferrer"
              className="block outline-none"
            >
              <div className="group relative overflow-hidden rounded-2xl border border-primary/20 bg-card hover:bg-secondary/40 transition-all duration-300 shadow-sm hover:shadow-md">
                <div className="absolute inset-0 bg-primary/5 translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-in-out" />
                <div className="relative z-10 flex items-center gap-4 px-6 py-5">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center shrink-0 group-hover:scale-110 group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs uppercase tracking-widest font-semibold text-primary/70 mb-0.5">Resources</div>
                    <div className="text-lg md:text-xl font-serif text-primary leading-tight">Click here for brochures</div>
                  </div>
                  <ArrowUpRight className="w-5 h-5 text-primary shrink-0 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </div>
              </div>
            </a>
          </SectionReveal>

        </div>
      </div>
    </PageTransition>
  );
}
