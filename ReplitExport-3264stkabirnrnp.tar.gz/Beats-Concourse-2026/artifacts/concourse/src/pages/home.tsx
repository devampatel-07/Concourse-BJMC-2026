import { PageTransition, SectionReveal, StaggerContainer, StaggerItem, usePageTitle } from "@/components/animations";
import { Card, CardContent } from "@/components/ui/card";
import { ChevronDown } from "lucide-react";

export default function Home() {
  usePageTitle("Home");

  const highlights = [
    {
      title: "Key Note Lectures",
      description: "Two inspiring sessions by distinguished experts, sharing insights on emerging and future trends in medicine.",
      icon: "01"
    },
    {
      title: "Workshops",
      description: "Hands-on workshops conducted across three days to enhance practical and clinical skills.",
      icon: "02"
    },
    {
      title: "Quizzes",
      description: "Competitive national-level academic quizzes covering preclinical, paraclinical and clinical subjects.",
      icon: "03"
    },
    {
      title: "Research Presentation",
      description: "Poster and paper presentations providing a platform to showcase innovation and scientific research.",
      icon: "04"
    }
  ];

  return (
    <PageTransition>
      {/* Hero Section */}
      <section className="relative min-h-[90dvh] flex items-center justify-center pt-20 overflow-hidden">
        {/* Subtle background element */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,hsl(var(--primary)/0.05),transparent_50%)] pointer-events-none" />
        
        <div className="container px-4 md:px-6 relative z-10 flex flex-col items-center text-center">
          <SectionReveal delay={0.1}>
            <div className="mb-8 relative w-32 h-32 md:w-48 md:h-48 mx-auto">
              <div className="absolute inset-0 bg-primary/10 blur-3xl rounded-full scale-150 animate-pulse pointer-events-none" />
              <img 
                src="https://i.imgur.com/W9yGtjo.png" 
                alt="Concourse Logo" 
                className="w-full h-full relative z-10 rounded-full shadow-xl object-cover"
              />
            </div>
          </SectionReveal>
          
          <SectionReveal delay={0.2}>
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif font-bold text-primary mb-4 tracking-tight">
              Concourse
            </h1>
          </SectionReveal>
          
          <SectionReveal delay={0.3}>
            <p className="text-xl md:text-3xl font-light text-muted-foreground mb-6 font-serif italic">
              "Where splendid minds come together"
            </p>
          </SectionReveal>
          
          <SectionReveal delay={0.4}>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary text-secondary-foreground text-sm font-medium uppercase tracking-widest">
              <span>B.J. Medical College</span>
              <span className="w-1 h-1 rounded-full bg-primary" />
              <span>Ahmedabad</span>
            </div>
          </SectionReveal>
        </div>

        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <ChevronDown className="w-6 h-6 text-muted-foreground" />
        </div>
      </section>

      {/* About Section */}
      <section className="py-24 md:py-32 bg-primary text-primary-foreground relative overflow-hidden">
        <div className="container px-4 md:px-6 max-w-4xl mx-auto text-center">
          <SectionReveal>
            <h2 className="text-sm font-sans uppercase tracking-[0.3em] text-primary-foreground/60 mb-8">About the Conference</h2>
            <p className="text-2xl md:text-4xl leading-relaxed font-serif font-light text-white">
              Concourse is the annual UG medical conference of BJMC. Concourse has been one of the pioneering UG medical conferences of Gujarat, consistently hosting interactive hands-on sessions led by highly experienced educators. This aims at bridging the gap between the theoretical knowledge and the real-world applications.
            </p>
          </SectionReveal>
        </div>
      </section>

      {/* Highlights Section */}
      <section className="py-24 md:py-32 bg-background">
        <div className="container px-4 md:px-6">
          <SectionReveal>
            <div className="text-center mb-16 md:mb-24">
              <h2 className="text-4xl md:text-6xl font-serif text-primary mb-4">Events spanning 3 days</h2>
              <div className="w-24 h-1 bg-primary/20 mx-auto rounded-full" />
            </div>
          </SectionReveal>

          <StaggerContainer className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 max-w-6xl mx-auto">
            {highlights.map((item, i) => (
              <StaggerItem key={i}>
                <Card className="h-full bg-card border-none shadow-sm hover:shadow-md transition-all duration-300 group overflow-hidden relative">
                  <CardContent className="p-8 md:p-10 relative z-10">
                    <div className="text-sm font-mono font-semibold text-primary/40 mb-3 tracking-widest">
                      {item.icon}
                    </div>
                    <h3 className="text-2xl font-serif text-primary mb-4 group-hover:text-primary/80 transition-colors">
                      {item.title}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed text-lg">
                      {item.description}
                    </p>
                  </CardContent>
                </Card>
              </StaggerItem>
            ))}
          </StaggerContainer>
        </div>
      </section>

    </PageTransition>
  );
}
