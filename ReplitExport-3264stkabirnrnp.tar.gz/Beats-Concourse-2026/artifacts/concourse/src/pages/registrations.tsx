import { Link } from "wouter";
import { PageTransition, SectionReveal, usePageTitle } from "@/components/animations";
import { ArrowUpRight, UtensilsCrossed } from "lucide-react";

type Workshop = { name: string; type: "Major" | "Minor" };
type DayWorkshops = { day: string; date: string; workshops: Workshop[] };

const WORKSHOP_DAYS: DayWorkshops[] = [
  {
    day: "Day 1",
    date: "22nd May",
    workshops: [
      { name: "Cardiology", type: "Major" },
      { name: "Orthopedics", type: "Major" },
      { name: "Suturing", type: "Major" },
      { name: "ENT", type: "Major" },
      { name: "Oncopathology", type: "Minor" },
      { name: "Pulmonology", type: "Minor" },
      { name: "Research", type: "Minor" },
      { name: "Psychiatry", type: "Minor" },
      { name: "Dermatology", type: "Minor" },
    ],
  },
  {
    day: "Day 2",
    date: "23rd May",
    workshops: [
      { name: "Obstetrics & Gynecology", type: "Major" },
      { name: "Pediatrics", type: "Major" },
      { name: "Laparoscopy", type: "Major" },
      { name: "Nuclear Medicine", type: "Minor" },
      { name: "Neurology", type: "Minor" },
      { name: "Nephrology", type: "Minor" },
    ],
  },
];

const PRICING = [
  { label: "1 Minor workshop", note: "one day lunch included", price: "₹700" },
  { label: "1 Major workshop", note: "one day lunch included", price: "₹800" },
  { label: "Major + Minor workshop", note: "two days lunch included", price: "₹1,200" },
];

export default function Registrations() {
  usePageTitle("Registrations");

  return (
    <PageTransition>
      <div className="pt-28 pb-0 md:pt-36">
        <div className="container px-4 md:px-6 max-w-5xl mx-auto pb-20 md:pb-28">

          {/* Heading */}
          <SectionReveal>
            <div className="text-center mb-16 max-w-3xl mx-auto">
              <h1 className="text-5xl md:text-7xl font-serif text-primary mb-6">Registrations</h1>
              <p className="text-xl md:text-2xl text-muted-foreground font-light leading-relaxed">
                There will be three options — only a minor workshop, only a major workshop, or one of each (on different days).
              </p>
            </div>
          </SectionReveal>

          {/* Workshops by Day */}
          <SectionReveal>
            <div className="flex flex-col gap-6 mb-8">
              {WORKSHOP_DAYS.map((day) => {
                const majors = day.workshops.filter((w) => w.type === "Major");
                const minors = day.workshops.filter((w) => w.type === "Minor");
                return (
                  <div key={day.day} className="rounded-3xl overflow-hidden border border-border/40 shadow-sm">
                    {/* Header */}
                    <div className="bg-primary px-8 pt-7 pb-6 flex items-baseline justify-between gap-4">
                      <h2 className="text-5xl md:text-6xl font-serif font-bold text-primary-foreground leading-none tracking-tight">{day.day}</h2>
                      <span className="text-base md:text-lg font-serif text-primary-foreground/60 leading-none shrink-0">{day.date}</span>
                    </div>

                    {/* Body: two columns */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 divide-y sm:divide-y-0 sm:divide-x divide-border/40">
                      {/* Major */}
                      <div className="bg-card px-7 py-7">
                        <div className="flex items-center gap-2 mb-5">
                          <span className="w-3 h-3 rounded-full bg-primary shrink-0" />
                          <span className="text-xs uppercase tracking-[0.18em] font-bold text-primary">Major</span>
                        </div>
                        <ul className="space-y-3.5">
                          {majors.map((w) => (
                            <li key={w.name} className="text-base md:text-lg font-medium text-foreground pl-5 border-l-2 border-primary/20 leading-snug">
                              {w.name}
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Minor */}
                      <div className="bg-card px-7 py-7">
                        <div className="flex items-center gap-2 mb-5">
                          <span className="w-3 h-3 rounded-full border-2 border-primary/50 shrink-0" />
                          <span className="text-xs uppercase tracking-[0.18em] font-bold text-primary/70">Minor</span>
                        </div>
                        <ul className="space-y-3.5">
                          {minors.map((w) => (
                            <li key={w.name} className="text-base md:text-lg text-foreground/80 pl-5 border-l-2 border-primary/10 leading-snug">
                              {w.name}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Workshop notes */}
            <div className="bg-secondary/40 rounded-2xl border border-border/40 px-6 py-4 mb-16">
              <p className="text-base md:text-lg text-foreground/80">
                <span className="font-semibold text-primary">Note</span> — You can only select one workshop per day.
              </p>
            </div>
          </SectionReveal>

          {/* Pricing */}
          <SectionReveal>
            <h2 className="text-3xl md:text-5xl font-serif text-primary mb-8">Pricing</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-5">
              {PRICING.map((p, i) => (
                <div key={i} className="rounded-2xl border border-border/50 bg-card shadow-sm p-6 flex flex-col gap-3">
                  <div>
                    <div className="text-base font-semibold text-foreground mb-0.5">{p.label}</div>
                    <div className="text-xs text-muted-foreground">{p.note}</div>
                  </div>
                  <div className="text-3xl md:text-4xl font-sans font-bold tabular-nums tracking-tight text-primary">
                    {p.price}
                  </div>
                </div>
              ))}
            </div>
            <div className="flex items-start gap-2.5 px-5 py-3.5 rounded-xl bg-secondary/40 border border-border/40 mb-20">
              <UtensilsCrossed className="w-4 h-4 text-primary/60 shrink-0 mt-1" />
              <p className="text-base md:text-lg text-foreground/80">
                <span className="font-semibold text-primary">Note</span> — You can add lunch for the other day for ₹200.
              </p>
            </div>
          </SectionReveal>

          {/* Itinerary CTA */}
          <SectionReveal>
            <Link href="/itinerary" className="block outline-none">
              <div className="group relative overflow-hidden rounded-2xl border border-primary/20 bg-card hover:bg-secondary/40 transition-all duration-300 shadow-sm hover:shadow-md">
                <div className="absolute inset-0 bg-primary/5 translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-in-out" />
                <div className="relative z-10 flex items-center justify-between gap-4 px-7 py-6">
                  <div>
                    <div className="text-xs uppercase tracking-widest font-semibold text-primary/70 mb-1">3-Day Schedule</div>
                    <div className="text-2xl md:text-3xl font-serif text-primary leading-tight">View Itinerary</div>
                  </div>
                  <ArrowUpRight className="w-6 h-6 text-primary shrink-0 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </div>
              </div>
            </Link>
          </SectionReveal>

        </div>

        {/* Registration Form Embed */}
        <div className="mt-16 md:mt-24 px-4 md:px-6 pb-20">
          <div className="text-center mb-8 max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-serif text-primary mb-3">Workshop Registration Form</h2>
            <p className="text-muted-foreground">Fill out the form below to register for your workshop(s).</p>
          </div>
          <div className="w-full max-w-5xl mx-auto bg-card rounded-3xl overflow-hidden border border-border shadow-lg">
            <iframe
              src="https://tally.so/r/XxOEjz"
              className="w-full border-0 block"
              style={{ height: "min(1600px, 220vh)", minHeight: "1200px" }}
              title="Workshop Registration Form"
              loading="lazy"
            >
              Loading…
            </iframe>
          </div>
        </div>

      </div>
    </PageTransition>
  );
}
