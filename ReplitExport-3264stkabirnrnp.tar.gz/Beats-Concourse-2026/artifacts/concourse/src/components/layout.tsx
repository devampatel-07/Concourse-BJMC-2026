import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";

const NAV_LINKS = [
  { href: "/", label: "Home" },
  { href: "/registrations", label: "Registrations" },
  { href: "/quiz", label: "Quiz" },
  { href: "/posters", label: "Posters" },
  { href: "/contact", label: "Contact" },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="min-h-[100dvh] flex flex-col selection:bg-primary selection:text-primary-foreground">
      <header
        className={`fixed top-0 w-full z-50 transition-all duration-300 ${
          isScrolled
            ? "bg-background/90 backdrop-blur-md border-b shadow-sm"
            : "bg-background/70 backdrop-blur-sm border-b border-border/30"
        }`}
      >
        {/* Top row: logo */}
        <div className="container mx-auto px-4 md:px-6 flex items-center justify-between py-3 md:py-4">
          <Link href="/" className="flex items-center gap-3 group">
            <img
              src="https://i.imgur.com/W9yGtjo.png"
              alt="Concourse Logo"
              className="w-9 h-9 md:w-11 md:h-11 rounded-full shadow-sm transition-transform duration-500 group-hover:rotate-[360deg]"
            />
            <span className="font-serif text-xl md:text-2xl font-semibold text-primary tracking-tight">
              Concourse
            </span>
          </Link>

          {/* Desktop nav — same row as logo */}
          <nav className="hidden md:flex items-center gap-7">
            {NAV_LINKS.map((link) => {
              const active = location === link.href || (link.href !== "/" && location.startsWith(link.href));
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`text-sm font-medium transition-colors relative pb-0.5 ${
                    active ? "text-primary" : "text-muted-foreground hover:text-primary"
                  }`}
                >
                  {link.label}
                  {active && (
                    <motion.div
                      layoutId="navbar-indicator"
                      className="absolute -bottom-1 left-0 right-0 h-0.5 bg-primary rounded-full"
                      transition={{ type: "spring", stiffness: 300, damping: 30 }}
                    />
                  )}
                </Link>
              );
            })}
          </nav>
        </div>

        {/* Mobile nav — second row, horizontally scrollable */}
        <div className="md:hidden w-full border-t border-border/40 overflow-x-auto scrollbar-none">
          <nav className="flex items-center gap-1 px-3 py-2 w-max min-w-full">
            {NAV_LINKS.map((link) => {
              const active = location === link.href || (link.href !== "/" && location.startsWith(link.href));
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`relative shrink-0 px-3 py-1.5 rounded-full text-sm font-medium transition-all duration-200 ${
                    active
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:text-primary hover:bg-primary/8"
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
          </nav>
        </div>
      </header>

      <main className="flex-1 flex flex-col">
        {children}
      </main>

      <footer className="bg-primary text-primary-foreground py-12 mt-auto">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <img src="https://i.imgur.com/W9yGtjo.png" alt="Concourse" className="w-8 h-8 rounded-full bg-white p-0.5" />
                <span className="font-serif text-xl font-semibold">Concourse</span>
              </div>
              <p className="text-primary-foreground/80 max-w-sm">
                Where splendid minds come together. The annual undergraduate medical conference of B.J. Medical College, Ahmedabad.
              </p>
            </div>

            <div>
              <h3 className="font-serif text-lg mb-4">Quick Links</h3>
              <ul className="space-y-2 text-primary-foreground/80">
                {NAV_LINKS.map((link) => (
                  <li key={link.href}>
                    <Link href={link.href} className="hover:text-white transition-colors">{link.label}</Link>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="font-serif text-lg mb-4">Contact</h3>
              <ul className="space-y-2 text-primary-foreground/80">
                <li><a href="mailto:beatsconcourse@gmail.com" className="hover:text-white transition-colors">beatsconcourse@gmail.com</a></li>
                <li><a href="https://instagram.com/beatsconcourse" target="_blank" rel="noreferrer" className="hover:text-white transition-colors">@beatsconcourse</a></li>
                <li className="pt-2">B.J. Medical College,<br />Asarwa, Ahmedabad</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-primary-foreground/20 mt-12 pt-8 text-center text-primary-foreground/60 text-sm">
            <p>© {new Date().getFullYear()} BJMC Concourse. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
